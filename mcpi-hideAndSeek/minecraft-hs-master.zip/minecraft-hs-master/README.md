-------------------------------------------------------------------------------
Minecraft - Hide and Seek
Martin O'Hanlon (martin@ohanlonweb.com)
http://www.stuffaboutcode.com
-------------------------------------------------------------------------------

A hide and seek game for MineCraft: Pi edition
http://www.stuffaboutcode.com/2013/01/raspberry-pi-minecraft-hide-and-seek.html

------------------------------------------------------------------------------

Version history
0.1 - first beta release

-------------------------------------------------------------------------------
